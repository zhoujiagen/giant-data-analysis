# 设置ZOOKEEPER_HOME环境变量
export ZOOKEEPER_HOME=/Users/jiedong/software/zookeeper-3.4.6
echo "The ZooKeeper home is: " $ZOOKEEPER_HOME

cd z1
./start.sh
cd ../z2
./start.sh
cd ../z3
./start.sh
cd ..

# 生成客户端连接脚本
echo $ZOOKEEPER_HOME/bin/zkCli.sh -server 127.0.0.1:2181,127.0.0.1:2182,127.0.0.1:2183 > client.sh

echo "start all done."
