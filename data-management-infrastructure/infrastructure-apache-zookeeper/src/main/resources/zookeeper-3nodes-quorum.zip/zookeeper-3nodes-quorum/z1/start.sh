$ZOOKEEPER_HOME/bin/zkServer.sh start ./zoo.cfg
