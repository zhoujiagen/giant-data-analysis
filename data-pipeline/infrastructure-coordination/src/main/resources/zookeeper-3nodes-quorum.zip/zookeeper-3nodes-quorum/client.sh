/Users/zhoujiagen/software/zookeeper-3.4.6/bin/zkCli.sh -server 127.0.0.1:2181,127.0.0.1:2182,127.0.0.1:2183
